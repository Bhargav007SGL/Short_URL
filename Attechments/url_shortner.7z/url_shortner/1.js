const sgMail = require("@sendgrid/mail");
const fs = require('fs');
var apiKey = `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`;
sgMail.setApiKey(apiKey);

pathToAttachment = `${__dirname}/Attechments/demo.7z`;
attachment = fs.readFileSync(pathToAttachment).toString("base64");

const msg = {
  to: "bhargav.v@sgligis.com", 
  from: "bhargav.v@sgligis.com",
  subject: "Project",
  html: `Done...`,
  attachments: [
    {
      content: attachment,
      filename: "demo.7z",
      type: "zip",
      disposition: "attachment"
    }
  ]
};
sgMail
  .send(msg)
  .then(() => {
    console.log("Email sent");
  })
  .catch((error) => {
    console.error(error);
  });