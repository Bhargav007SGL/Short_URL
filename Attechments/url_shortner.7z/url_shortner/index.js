require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();
const dns = require("dns");
var bodyParser = require('body-parser')
const fs = require('fs');
const { json } = require('body-parser');

// Basic Configuration
const port = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }))
app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function(req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

// Your first API endpoint
app.get('/api/hello', function(req, res) {
  res.json({ greeting: 'hello API' });
});

app.post('/api/shorturl', function(req, res) {
  var rendomNumber = parseInt(Math.random()*1000)
  var orignalURL = req.body.url;
  const REPLACE_REGEX = /^https?:\/\//i;
  orignalURL = orignalURL.replace(REPLACE_REGEX, '');
  orignalURL = orignalURL.slice(0,orignalURL.indexOf("/"));
  dns.lookup(orignalURL, (error, address, family) => {
    if (error) {
      return res.send({ error: 'invalid url' })
    } 
    var short_URLObj = {"original_url":req.body.url,"short_url":rendomNumber};
    try
    {
    var shortData = fs.readFileSync(`./short_url.json`);
    shortData = shortData.toString();
    }
    catch(e)
    {
      fs.writeFileSync(`short_url.json`,`[]`)
    }
    res.send(short_URLObj);
  });
});

app.get('/api/shorturl/:number', function(req, res) {
  var number = req.params.number;
  var fetchData = fs.readFileSync('./short_url.json');
  console.log(fetchData);

});

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});
